const validators = require('myscripts_validators');

function validate(task) {
    validators.mustStringOrMissing(task.request, "request");
    validators.mustStringOrMissing(task.encrypt, "encrypt");
    validators.mustStringOrMissing(task.decrypt, "decrypt");
    validators.mustStringOrMissingValues(task.channel, "channel", ["trusted", "controlled"]);
    validators.mustStringOrMissing(task.extra, "extra");
}

function validateTask(task) {
    try {
        validate(task);
    } catch (e) {
        if (e.name === "InvalidJsonValueError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Некорректное значение поля \"" + e.path + "\" (" + e.value + ")")
        } else if (e.name === "InvalidJsonTypeError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" имеет неверный тип (ожидается \"" + e.expectedType + "\")");
        } else if (e.name === "JsonValueNotFoundError") {
            return Fptr.result(Fptr.LIBFPTR_ERROR_RECEIPT_PARSE_ERROR, "Поле \"" + e.path + "\" отсутствует");
        } else {
            throw e;
        }
    }
    return Fptr.ok();
}

function execute(task) {
    v = validateTask(task);
    if (v.isError) {
        return v;
    }

    if (!validators.isMissing(task.request)) {
        try {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_REQUEST_DATA, Duktape.dec("base64", task.request));
        } catch (e) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_REQUEST_DATA, task.request);
        }
    }

    if (!validators.isMissing(task.encrypt)) {
        try {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_ENCRYPT_DATA, Duktape.dec("base64", task.encrypt));
        } catch (e) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_ENCRYPT_DATA, task.encrypt);
        }
    }

    if (!validators.isMissing(task.decrypt)) {
        try {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_DECRYPT_DATA, Duktape.dec("base64", task.decrypt));
        } catch (e) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_DECRYPT_DATA, task.decrypt);
        }
    }

    if (!validators.isMissing(task.extra)) {
        try {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_EXTRA_DATA, Duktape.dec("base64", task.extra));
        } catch (e) {
            Fptr.setParam(Fptr.LIBFPTR_PARAM_EXTRA_DATA, task.extra);
        }
    }

    if (!validators.isMissing(task.channel)) {
        switch (task.channel) {
            case "trusted":
                Fptr.setParam(Fptr.LIBFPTR_PARAM_CHANNEL_TYPE, Fptr.LIBFPTR_CT_TRUSTED);
                break;
            case "controlled":
                Fptr.setParam(Fptr.LIBFPTR_PARAM_CHANNEL_TYPE, Fptr.LIBFPTR_CT_CONTROLLED);
                break;
        }
    }



    if (Fptr.formPirsRequest() < 0) {
        return Fptr.error();
    }
    var array = Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_REQUEST_DATA);

    answer = {};
    answer.request = Duktape.enc("base64", array);

    if (Fptr.isParamAvailable(Fptr.LIBFPTR_PARAM_EXTRA_DATA)) {
        answer.extra = Duktape.enc("base64", Fptr.getParamByteArray(Fptr.LIBFPTR_PARAM_EXTRA_DATA));
    }

    if (!validators.isMissing(task.decrypt)) {
        var x_fn_sid_str = '';

        for (var i = 0; i < array.length; i++) {
            x_fn_sid_str += String.fromCharCode(array[i]);
        }
        answer.x_fn_sid = x_fn_sid_str;
    } 

    return Fptr.ok(answer)
}
