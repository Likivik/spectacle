const utils = require('myscripts_utils');
function execute(task) {
    var licensesInformation = [];
    Fptr.setParam(Fptr.LIBFPTR_PARAM_RECORDS_TYPE, Fptr.LIBFPTR_RT_LICENSES);
    if (Fptr.beginReadRecords() < 0) {
        return Fptr.error();
    } else {
        while (Fptr.readNextRecord() === Fptr.LIBFPTR_OK) {
            licenseInfo = {};
            licenseInfo.id = Fptr.getParamString(Fptr.LIBFPTR_PARAM_LICENSE_NUMBER);
            licenseInfo.name = Fptr.getParamString(Fptr.LIBFPTR_PARAM_LICENSE_NAME);
            licenseInfo.validFrom = utils.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_LICENSE_VALID_FROM));
            licenseInfo.validUntil = utils.dateToIsoString(Fptr.getParamDateTime(Fptr.LIBFPTR_PARAM_LICENSE_VALID_UNTIL));
            var unitVersion = Fptr.getParamString(Fptr.LIBFPTR_PARAM_UNIT_VERSION);
            if ((unitVersion !== "") && (licenseInfo.id == 16)) {
                licenseInfo.unitVersion = unitVersion;
            }
            licensesInformation.push(licenseInfo);
        }
        Fptr.endReadRecords();
    }

    return Fptr.ok({
        licenses: licensesInformation
    });
}
