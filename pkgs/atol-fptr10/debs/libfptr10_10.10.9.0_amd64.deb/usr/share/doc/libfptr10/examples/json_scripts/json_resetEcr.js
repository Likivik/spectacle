function execute(task) {

	Fptr.setParam(Fptr.LIBFPTR_PARAM_DATA_TYPE, Fptr.LIBFPTR_DT_SHIFT_STATE);
	if (Fptr.queryData() < 0) {
		return Fptr.error();
	}
	if (Fptr.getParamInt(Fptr.LIBFPTR_PARAM_SHIFT_STATE) != Fptr.LIBFPTR_SS_CLOSED) {
		return Fptr.result(Fptr.LIBFPTR_ERROR_DENIED_IN_OPENED_SHIFT);
	}

	Fptr.setParam(Fptr.LIBFPTR_PARAM_FULL_RESET, 2);
	if (Fptr.resetSettings() < 0) {
		return Fptr.error();
	}

	if (Fptr.deviceReboot() < 0) {
		return Fptr.error();
	}

	return Fptr.ok();
}
